Tic Tac Toe

instructions
--------------
1)Open .exe
2)Player One enter both Row and Column you want to place your marker
3)Player Two enter both Row and Column you want to place your marker
4)Try and get three of your markers in a row


Created by Forrest McCarthy